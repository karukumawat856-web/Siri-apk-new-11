package com.siri.assistant

import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** OpenAI-compatible client. Base URL / key / models Settings (⚙) me set karo. */
class AiClient(private val ctx: Context) {
    private val http = OkHttpClient.Builder().readTimeout(180, TimeUnit.SECONDS).build()
    private val sp = ctx.getSharedPreferences("siri", 0)
    private val history = JSONArray()
    private val json = "application/json".toMediaType()

    fun get(k: String, d: String) = sp.getString(k, d) ?: d
    fun set(k: String, v: String) = sp.edit().putString(k, v).apply()

    private fun post(url: String, body: JSONObject): Response {
        val req = Request.Builder().url(url).header("Authorization", "Bearer " + get("key", ""))
            .post(body.toString().toRequestBody(json)).build()
        val r = http.newCall(req).execute()
        if (!r.isSuccessful) { val m = r.body?.string(); r.close(); throw RuntimeException("HTTP ${r.code}: $m") }
        return r
    }
    private val base get() = get("base", "https://api.openai.com/v1").trimEnd('/')

    fun chat(msg: String): String {
        history.put(JSONObject().put("role", "user").put("content", msg))
        val msgs = JSONArray().put(JSONObject().put("role", "system")
            .put("content", "Tum 'Siri' ho, user ki personal AI assistant. User Hinglish/Hindi/English me bolta hai, usi language me chhota jawab do."))
        for (i in maxOf(0, history.length() - 20) until history.length()) msgs.put(history.get(i))
        val r = post("$base/chat/completions", JSONObject().put("model", get("chat_model", "gpt-4o-mini")).put("messages", msgs))
        val out = JSONObject(r.body!!.string()).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        history.put(JSONObject().put("role", "assistant").put("content", out))
        return out
    }

    /** returns Pair(base64 or null, url or null) */
    fun image(prompt: String): Pair<String?, String?> {
        val r = post("$base/images/generations", JSONObject().put("model", get("image_model", "gpt-image-1")).put("prompt", prompt).put("n", 1))
        val d = JSONObject(r.body!!.string()).getJSONArray("data").getJSONObject(0)
        return d.optString("b64_json").ifEmpty { null } to d.optString("url").ifEmpty { null }
    }

    /** Text -> speech mp3 bytes */
    fun tts(text: String): ByteArray {
        val r = post("$base/audio/speech", JSONObject().put("model", get("tts_model", "gpt-4o-mini-tts")).put("input", text).put("voice", "alloy"))
        return r.body!!.bytes()
    }

    /** Video: provider ke hisaab se video endpoint badlo. Response me "url" ya data[0].url chahiye. */
    fun video(prompt: String): String {
        val endpoint = get("video_url", "")
        if (endpoint.isEmpty()) throw RuntimeException("Settings me Video API URL daalo")
        val r = post(endpoint, JSONObject().put("model", get("video_model", "")).put("prompt", prompt))
        val j = JSONObject(r.body!!.string())
        return j.optString("url").ifEmpty { j.optJSONArray("data")?.optJSONObject(0)?.optString("url") ?: "" }
            .ifEmpty { throw RuntimeException("Response me video url nahi mila: $j") }
    }
}
