package com.siri.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.accessibilityservice.AccessibilityService as AS

object CommandRouter {
    private val wake = Regex("^(hey |ok |hello |hi )?(siri|सिरी)[,!. ]*", RegexOption.IGNORE_CASE)

    /** Returns reply text if it was a phone command, else null (-> goes to AI chat). */
    fun handle(ctx: Context, raw: String): String? {
        val t = raw.trim().replace(wake, "").trim().lowercase()
        if (t.isEmpty()) return "Ji, boliye!"

        Regex("^(?:open|launch|kholo|khol)\\s+(.+)$").find(t)?.let { return openApp(ctx, it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:kholo|khol do|open karo|open kar do|open kar)$").find(t)?.let { return openApp(ctx, it.groupValues[1]) }
        Regex("^(?:call|dial|phone lagao)\\s+([+0-9 ]+)$").find(t)?.let {
            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[1].replace(" ", ""))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Dial kar raha hoon ${it.groupValues[1]}"
        }
        Regex("^(?:search|google|dhundo)\\s+(.+)$").find(t)?.let {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1]))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Search: ${it.groupValues[1]}"
        }

        val needsAcc = when {
            t in listOf("back", "wapas", "peeche", "go back") -> AS.GLOBAL_ACTION_BACK to "Back"
            t in listOf("home", "home screen", "ghar") -> AS.GLOBAL_ACTION_HOME to "Home"
            t.startsWith("recent") -> AS.GLOBAL_ACTION_RECENTS to "Recents"
            t.startsWith("notification") -> AS.GLOBAL_ACTION_NOTIFICATIONS to "Notifications"
            t.contains("screenshot") -> AS.GLOBAL_ACTION_TAKE_SCREENSHOT to "Screenshot le liya"
            t.contains("lock screen") -> AS.GLOBAL_ACTION_LOCK_SCREEN to "Screen lock"
            else -> null
        }
        val isScroll = Regex("^scroll\\s+(down|up)|^(neeche|upar)").find(t)
        val click = Regex("^(?:click|tap|press|dabao)\\s+(?:on\\s+)?(.+)$").find(t)
        val type = Regex("^(?:type|likho)\\s+(.+)$").find(t)

        if (needsAcc == null && isScroll == null && click == null && type == null) return null

        val svc = SiriAccessibilityService.instance ?: run {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Pehle Accessibility me 'Siri Control' ON karo."
        }
        needsAcc?.let { svc.global(it.first); return it.second }
        isScroll?.let { val down = it.value.contains("down") || it.value.contains("neeche"); return if (svc.scroll(down)) "Scroll done" else "Scroll nahi mila" }
        click?.let { return if (svc.clickText(it.groupValues[1])) "Click: ${it.groupValues[1]}" else "'${it.groupValues[1]}' screen par nahi mila" }
        type?.let { return if (svc.typeText(it.groupValues[1])) "Type kar diya" else "Pehle text box select karo" }
        return null
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(i, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name.trim())
        } ?: return "'$name' app nahi mila"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "Open nahi ho paya"
        ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "${match.loadLabel(pm)} khol diya"
    }
}
