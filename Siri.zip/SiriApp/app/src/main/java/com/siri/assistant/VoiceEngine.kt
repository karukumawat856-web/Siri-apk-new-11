package com.siri.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceEngine(private val ctx: Context) {
    private val tts: TextToSpeech = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts2().language = Locale("hi", "IN") }
    private fun tts2() = tts
    private var rec: SpeechRecognizer? = null

    fun speak(t: String) { tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "siri") }

    fun listen(onResult: (String) -> Unit, onError: (String) -> Unit) {
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx); rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onResult)
            }
            override fun onError(e: Int) = onError("Mic error $e")
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
    }
    fun destroy() { rec?.destroy(); tts.shutdown() }
}
