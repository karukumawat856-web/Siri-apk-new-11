package com.siri.assistant

import android.Manifest
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var ai: AiClient
    private lateinit var voice: VoiceEngine
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private var speakReplies = true

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        ai = AiClient(this); voice = VoiceEngine(this)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this); bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(status); root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        input = EditText(this).apply { hint = "Siri se kuch bhi kaho ya likho..." }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 12f; setOnClickListener { f() } }
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row1.addView(btn("🎤") { listen() }); row1.addView(btn("Send") { send() })
        row1.addView(btn("🖼") { genImage() }); row1.addView(btn("🎬") { genVideo() })
        row1.addView(btn("🔊") { genVoice() }); row1.addView(btn("⚙") { settings() })
        root.addView(row1)
        setContentView(root)
        add("Siri", "Namaste! Mic dabao ya likho.\n🖼 image • 🎬 video • 🔊 voice (text likh ke button dabao)\nPhone control ke liye Accessibility ON karo.")
    }

    private fun add(who: String, msg: String): TextView {
        val tv = TextView(this).apply { text = "$who: $msg"; textSize = 15f; setPadding(0, 12, 0, 12); setTextIsSelectable(true) }
        log.addView(tv); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }; return tv
    }
    private fun progress(p: Int, label: String) = runOnUiThread {
        bar.visibility = View.VISIBLE
        if (p < 0) { bar.isIndeterminate = true; status.text = "$label..." } else { bar.isIndeterminate = false; bar.progress = p; status.text = "$label $p%" }
        if (p >= 100) { bar.visibility = View.GONE; status.text = "" }
    }
    private fun done() = runOnUiThread { bar.visibility = View.GONE; status.text = "" }
    private fun mediaDir() = File(getExternalFilesDir(null), "Siri").apply { mkdirs() }

    private fun listen() { status.text = "Sun raha hoon..."; voice.listen({ status.text = ""; input.setText(it); send() }, { status.text = it }) }

    private fun send() {
        val t = input.text.toString().trim(); if (t.isEmpty()) return
        input.setText(""); add("Aap", t)
        CommandRouter.handle(this, t)?.let { add("Siri", it); if (speakReplies) voice.speak(it); return }
        run("Soch raha hoon") {
            val r = withContext(Dispatchers.IO) { ai.chat(t) }
            add("Siri", r); if (speakReplies) voice.speak(r)
        }
    }

    private fun prompt(): String? { val t = input.text.toString().trim(); if (t.isEmpty()) { Toast.makeText(this, "Pehle prompt likho", 0).show(); return null }; input.setText(""); add("Aap", t); return t }

    private fun genImage() { val p = prompt() ?: return
        run("Image ban rahi hai") {
            val f = withContext(Dispatchers.IO) {
                val (b64, url) = ai.image(p); val f = File(mediaDir(), "img_${System.currentTimeMillis()}.png")
                if (b64 != null) f.writeBytes(Base64.decode(b64, Base64.DEFAULT)) else Downloader.download(url!!, f) { progress(it, "Image download") }
                f
            }
            val iv = ImageView(this).apply { setImageBitmap(BitmapFactory.decodeFile(f.path)); adjustViewBounds = true }
            log.addView(iv); add("Siri", "Saved: ${f.path}")
        } }

    private fun genVideo() { val p = prompt() ?: return
        run("Video ban rahi hai") {
            val f = withContext(Dispatchers.IO) {
                val url = ai.video(p); Downloader.download(url, File(mediaDir(), "vid_${System.currentTimeMillis()}.mp4")) { progress(it, "Video download") }
            }
            val vv = VideoView(this).apply { setMediaController(MediaController(this@MainActivity).also { it.setAnchorView(this) }); setVideoPath(f.path) }
            log.addView(vv, LinearLayout.LayoutParams(-1, 600)); vv.start(); add("Siri", "Saved: ${f.path}")
        } }

    private fun genVoice() { val p = prompt() ?: return
        run("Voice ban rahi hai") {
            val f = withContext(Dispatchers.IO) { File(mediaDir(), "voice_${System.currentTimeMillis()}.mp3").also { it.writeBytes(ai.tts(p)) } }
            MediaPlayer().apply { setDataSource(f.path); prepare(); start() }; add("Siri", "Voice saved: ${f.path}")
        } }

    private fun run(label: String, block: suspend () -> Unit) {
        progress(-1, label)
        lifecycleScope.launch { try { block() } catch (e: Exception) { add("Error", e.message ?: e.toString()) } finally { done() } }
    }

    private fun settings() {
        val keys = listOf("base" to "Base URL (https://api.openai.com/v1)", "key" to "API Key", "chat_model" to "Chat model", "image_model" to "Image model",
            "tts_model" to "Voice (TTS) model", "video_url" to "Video API URL", "video_model" to "Video model")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0) }
        val edits = keys.map { (k, h) -> EditText(this).apply { hint = h; setText(ai.get(k, "")); box.addView(this) } }
        val sw = Switch(this).apply { text = "Jawab bolkar sunao"; isChecked = speakReplies; box.addView(this) }
        AlertDialog.Builder(this).setTitle("Settings").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ -> keys.forEachIndexed { i, (k, _) -> ai.set(k, edits[i].text.toString().trim()) }; speakReplies = sw.isChecked }.show()
    }

    override fun onDestroy() { voice.destroy(); super.onDestroy() }
}
