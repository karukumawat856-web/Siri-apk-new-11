package com.siri.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

object Downloader {
    private val http = OkHttpClient()
    /** Download with live progress (0..100). Call from background thread. */
    fun download(url: String, dest: File, onProgress: (Int) -> Unit): File {
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("Download fail: ${r.code}")
            val body = r.body!!
            val total = body.contentLength()
            var done = 0L; var last = -1
            body.byteStream().use { inp -> dest.outputStream().use { out ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = inp.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    val p = if (total > 0) (done * 100 / total).toInt() else -1
                    if (p != last) { last = p; onProgress(p) }
                }
            } }
        }
        onProgress(100)
        return dest
    }
}
